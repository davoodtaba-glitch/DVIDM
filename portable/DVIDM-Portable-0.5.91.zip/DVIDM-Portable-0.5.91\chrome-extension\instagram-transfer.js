const MAX_TRACK_BYTES = 192 * 1024 * 1024;
const QUERY_CHUNK_BYTES = 2 * 1024 * 1024;

function mediaRange(value) {
  const match = value?.match(/^bytes (\d+)-(\d+)\/(\d+)$/i);
  if (!match) return null;
  const [start, end, total] = match.slice(1).map(Number);
  return Number.isSafeInteger(total) && start <= end && end < total ? { start, end, total } : null;
}

function queryWindow(url, start, end) {
  // URLSearchParams would reserialize the CDN signature and unrelated values.
  return url.replace(/([?&]bytestart=)\d+(?=&|$)/i, (_, key) => key + start)
    .replace(/([?&]byteend=)\d+(?=&|$)/i, (_, key) => key + end);
}

function readBox(view, offset) {
  if (offset + 8 > view.byteLength) return null;
  const size = view.getUint32(offset);
  if (size < 8 || offset + size > view.byteLength) return null;
  const type = String.fromCharCode(...new Uint8Array(view.buffer, view.byteOffset + offset + 4, 4));
  return { type, end: offset + size };
}

function indexedLength(bytes) {
  // A flat DASH sidx supplies the end of its last referenced fragment even
  // on CDNs whose byte-window responses omit Content-Range.
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  for (let offset = 0; offset < view.byteLength;) {
    const box = readBox(view, offset);
    if (!box) break;
    if (box.type === "sidx") {
      const version = view.getUint8(offset + 8);
      const wide = version === 1;
      const countOffset = offset + (wide ? 38 : 30);
      if (version > 1 || countOffset + 2 > box.end) return 0;
      const firstOffset = wide ? Number(view.getBigUint64(offset + 28)) : view.getUint32(offset + 24);
      const count = view.getUint16(countOffset);
      if (!count || countOffset + 2 + count * 12 > box.end) return 0;
      let end = box.end + firstOffset;
      for (let index = 0; index < count; index++) {
        const reference = view.getUint32(countOffset + 2 + index * 12);
        if (reference === 0 || reference >= 0x80000000) return 0;
        end += reference;
      }
      return Number.isSafeInteger(end) ? end : 0;
    }
    offset = box.end;
  }
  return 0;
}

async function fetchTrackBytes(url, request, rangeHeader) {
  let response;
  try {
    response = await request(url, {
      credentials: "same-origin",
      redirect: "follow",
      headers: rangeHeader ? { Range: rangeHeader } : {},
      signal: AbortSignal.timeout(20000)
    });
  } catch (error) {
    throw new Error(error.name === "TimeoutError" ? "CDN request timed out" : "CDN connection blocked");
  }
  if (!instagramCdnUrl(response.url)) {
    await response.body?.cancel();
    throw new Error("CDN redirected outside the media hosts");
  }
  if (!response.ok) throw new Error("CDN returned HTTP " + response.status);
  if (/^(?:text\/|application\/(?:json|xml))/i.test(response.headers.get("content-type") || "")) {
    throw new Error("CDN returned a page instead of media");
  }
  const range = mediaRange(response.headers.get("content-range"));
  const length = Number(response.headers.get("content-length"));
  if (length > MAX_TRACK_BYTES || range?.total > MAX_TRACK_BYTES) {
    await response.body?.cancel();
    throw new Error("Track exceeds 192 MB");
  }
  // Cap streaming responses as well, including when Content-Length is absent.
  const reader = response.body?.getReader();
  if (!reader) throw new Error("Empty CDN response");
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > MAX_TRACK_BYTES) throw new Error("Track exceeds 192 MB");
      chunks.push(value);
    }
  } finally {
    await reader.cancel().catch(() => {});
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return { bytes, range, status: response.status };
}

async function recoverInstagramTrack(entry, request = fetch) {
  const captured = instagramCdnUrl(entry.requestUrl);
  const source = instagramCdnUrl(entry.url);
  if (!captured || !source || captured.origin !== source.origin || captured.pathname !== source.pathname) {
    throw new Error("Invalid media address");
  }
  const observedStart = captured.href.match(/[?&]bytestart=(\d+)(?=&|$)/i)?.[1];
  const observedEnd = captured.href.match(/[?&]byteend=(\d+)(?=&|$)/i)?.[1];
  const query = observedStart !== undefined && observedEnd !== undefined;
  const observedLength = Number(observedEnd) - Number(observedStart) + 1;
  const parts = [];
  let offset = 0;
  let total = entry.bytes || 0;
  if (total > MAX_TRACK_BYTES) throw new Error("Track exceeds 192 MB");

  while (!total || offset < total) {
    const window = query && !total ? Math.max(8, Math.min(observedLength, QUERY_CHUNK_BYTES)) : QUERY_CHUNK_BYTES;
    const end = Math.min(total || MAX_TRACK_BYTES, offset + window) - 1;
    const address = query ? queryWindow(captured.href, offset, end) : source.href;
    const result = await fetchTrackBytes(address, request, query ? "" : "bytes=" + offset + "-" + end);
    const { bytes, range, status } = result;
    if (offset === 0) {
      const first = readBox(new DataView(bytes.buffer), 0);
      if (first?.type !== "ftyp") throw new Error("MP4 header missing at byte 0");
    }

    if (range) {
      if (range.start !== offset || range.end - range.start + 1 !== bytes.length ||
          (total && total !== range.total)) throw new Error("CDN returned a different byte range");
      total = range.total;
    } else if (status === 200 && !query && offset === 0) {
      if (total && total !== bytes.length) throw new Error("CDN returned an incomplete file");
      total = bytes.length;
    } else if ((status === 200 || status === 206) && query) {
      if (!total && offset === 0) total = indexedLength(bytes);
      if (!total || total > MAX_TRACK_BYTES) throw new Error("CDN did not report the track length");
      const expected = Math.min(end + 1, total) - offset;
      if (bytes.length !== expected && !(offset === 0 && bytes.length === total)) {
        throw new Error("CDN returned a different byte count");
      }
    } else {
      throw new Error("CDN did not confirm the byte range");
    }
    if (!bytes.length || offset + bytes.length > total) throw new Error("Invalid media size");
    parts.push(bytes);
    offset += bytes.length;
  }
  const file = new Blob(parts, { type: entry.kind === "audio" ? "audio/mp4" : "video/mp4" });
  let hasMovie = false;
  let hasData = false;
  let hasAudio = false;
  for (let position = 0; position < file.size;) {
    const header = new DataView(await file.slice(position, position + 16).arrayBuffer());
    if (header.byteLength < 8) throw new Error("MP4 ends inside a box");
    let size = header.getUint32(0);
    if (size === 1 && header.byteLength >= 16) size = Number(header.getBigUint64(8));
    if (size === 0) size = file.size - position;
    if (size < 8 || size > file.size - position) throw new Error("MP4 is incomplete");
    const type = header.getUint32(4);
    if (type === 0x6d6f6f76 && entry.requireAudio) {
      if (size > 16 * 1024 * 1024) throw new Error("MP4 metadata exceeds the supported size");
      const start = position + (header.getUint32(0) === 1 ? 16 : 8);
      const movie = new DataView(await file.slice(start, position + size).arrayBuffer());
      hasAudio ||= mp4HasAudio(movie);
    }
    hasMovie ||= type === 0x6d6f6f76; // moov
    hasData ||= type === 0x6d646174 && size > 8; // mdat
    position += size;
  }
  if (!hasMovie || !hasData) throw new Error("MP4 is missing its metadata or media data");
  if (entry.requireAudio && !hasAudio) throw new Error("MP4 has no audio track");
  return file;
}

function mp4HasAudio(view) {
  function children(start, end, type) {
    const matches = [];
    for (let position = start; position < end;) {
      const box = readBox(view, position);
      if (!box || box.end > end) break;
      if (box.type === type) matches.push({ start: position + 8, end: box.end });
      position = box.end;
    }
    return matches;
  }
  return children(0, view.byteLength, "trak").some((track) =>
    children(track.start, track.end, "mdia").some((media) =>
      children(media.start, media.end, "hdlr").some((handler) =>
        handler.end - handler.start >= 12 && view.getUint32(handler.start + 8) === 0x736f756e
      )
    )
  );
}
