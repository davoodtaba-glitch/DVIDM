(() => {
  if (!isInstagram(location.href)) return;

  const host = document.createElement("div");
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;display:none";
  const shadow = host.attachShadow({ mode: "closed" });
  const button = document.createElement("button");
  const label = "↓ Download with DVIDM";
  button.type = "button";
  button.textContent = label;
  button.style.cssText = "color:white;background:#154580;border:1px solid #fff8;border-radius:6px;" +
    "padding:5px 9px;cursor:pointer;font:600 12px/1.4 system-ui;box-shadow:0 2px 8px #0006;white-space:nowrap";
  const choices = document.createElement("div");
  choices.hidden = true;
  choices.style.cssText = "position:absolute;right:0;top:100%;width:210px;max-height:48vh;overflow:auto;" +
    "background:#122033;color:white;border:1px solid #fff5;border-radius:6px;padding:6px;" +
    "box-shadow:0 2px 8px #0008;font:12px/1.4 system-ui";
  button.setAttribute("aria-expanded", "false");
  shadow.append(button, choices);
  document.documentElement.append(host);

  let visibleVideo = null;
  let scheduled = false;
  let recording = false;

  function visiblePlayer() {
    let best = null;
    let bestArea = 0;
    let bestPlaying = false;
    for (const video of document.querySelectorAll("video")) {
      const rect = video.getBoundingClientRect();
      const left = Math.max(0, rect.left);
      const top = Math.max(0, rect.top);
      const width = Math.min(innerWidth, rect.right) - left;
      const height = Math.min(innerHeight, rect.bottom) - top;
      if (width < 100 || height < 80 || getComputedStyle(video).visibility !== "visible") continue;
      const area = width * height;
      const playing = !video.paused && !video.ended && video.readyState >= 2;
      if (playing !== bestPlaying ? playing : area > bestArea) {
        bestPlaying = playing;
        best = { video, left, top, width };
        bestArea = area;
      }
    }
    return best;
  }

  function update() {
    scheduled = false;
    const player = visiblePlayer();
    if (visibleVideo !== player?.video) {
      visibleVideo = player?.video;
      closeChoices();

      if (!button.disabled) button.textContent = label;
    }
    host.style.display = player ? "block" : "none";
    if (player) {
      host.style.left = Math.max(player.left + 6, player.left + player.width - host.offsetWidth - 6) + "px";
      host.style.top = player.top + 6 + "px";
    }
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(update);
  }

  function postForPlayer(video) {
    const linked = instagramPost(video?.closest("a[href]")?.href);
    if (linked) return linked;
    const article = video?.closest('article, [role="dialog"]');
    if (article) {
      const posts = new Map();
      for (const link of article.querySelectorAll("a[href]")) {
        const post = instagramPost(link.href);
        if (post) posts.set(post.shortcode, post);
      }
      if (posts.size === 1) return posts.values().next().value;
      if (posts.size > 1) return null;
    }
    return document.querySelectorAll("video").length === 1 ? instagramPost(location.href) : null;
  }

  async function resolvePlayer(video) {
    const page = location.origin + location.pathname;
    const source = video?.currentSrc;
    const post = postForPlayer(video);
    const urls = await findInstagramVideos(video, post);
    if (page !== location.origin + location.pathname ||
        (video && (!video.isConnected || video.currentSrc !== source ||
          postForPlayer(video)?.shortcode !== post?.shortcode))) return [];
    return urls;
  }

  function closeChoices() {
    choices.hidden = true;
    button.setAttribute("aria-expanded", "false");
  }

  function saveFile(file, filename) {
    const url = URL.createObjectURL(file);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  function showRecording(video, stillSelected, title, reason) {
    const note = document.createElement("div");
    note.textContent = reason;
    const option = document.createElement("button");
    option.type = "button";
    option.textContent = "Record this video with audio";
    option.style.cssText = "display:block;width:100%;margin-top:6px;padding:6px;cursor:pointer";
    option.addEventListener("click", async (event) => {
      event.stopPropagation();
      if (!event.isTrusted || recording || !stillSelected()) return;
      recording = true;
      option.disabled = true;
      button.disabled = true;
      note.textContent = "Recording from the beginning… Keep this video open.";
      try {
        const file = await recordInstagramPlayer(video, stillSelected, (percent) => {
          option.textContent = "Recording " + percent + "%";
        });
        if (!stillSelected()) throw new Error("Video changed");
        saveFile(file, "Instagram - " + title + (file.type.startsWith("video/mp4") ? ".mp4" : ".webm"));
        note.textContent = "Sent recording to Chrome Downloads";
      } catch (error) {
        note.textContent = error.message;
      } finally {
        recording = false;
        button.disabled = false;
        option.disabled = false;
        option.textContent = "Record this video with audio";
      }
    });
    choices.replaceChildren(note, option);
    choices.hidden = false;
    button.setAttribute("aria-expanded", "true");
  }

  button.addEventListener("click", async (event) => {
    event.stopPropagation();
    if (!event.isTrusted || !visibleVideo || button.disabled) return;
    if (!choices.hidden) {
      closeChoices();
      return;
    }
    const video = visibleVideo;
    const page = location.href;
    const source = video.currentSrc;
    const poster = video.poster;
    const post = postForPlayer(video);
    const stillSelected = () => video.isConnected && video.currentSrc === source &&
      video.poster === poster && location.href === page && postForPlayer(video)?.shortcode === post?.shortcode;
    const title = (document.title !== "Instagram" && !/^\(\d+\) Instagram$/.test(document.title)
      ? document.title : post?.shortcode || "video").replace(/[<>:"/\\|?*\x00-\x1f]/g, " ").trim().slice(0, 100) || "video";

    button.disabled = true;
    button.textContent = "Finding this video…";
    try {
      const urls = await resolvePlayer(video);
      if (!stillSelected()) return;
      if (urls.length !== 1) {
        showRecording(video, stillSelected, title, "Original file with audio unavailable. Recording takes the length of the video.");
        return;
      }
      const [url] = urls;
      const result = await chrome.runtime.sendMessage({ type: "dvidm-instagram-save", url, title });
      if (!stillSelected()) return;
      if (!result?.ok) {
        if (!result?.retry) throw new Error(result?.error || "Original file unavailable");
        const file = await recoverInstagramTrack({ url, requestUrl: url, kind: "mp4", requireAudio: true });
        if (!stillSelected()) return;
        saveFile(file, result.filename);
      }
      button.textContent = "Sent to Chrome Downloads";
    } catch (error) {
      if (stillSelected()) showRecording(video, stillSelected, title,
        error.message + ". Recording takes the length of the video.");
    } finally {
      button.disabled = false;
      if (!choices.hidden || !stillSelected()) button.textContent = label;
      if (button.textContent !== label) {
        setTimeout(() => { if (!button.disabled) button.textContent = label; }, 3000);
      }
      schedule();
    }
  });

  document.addEventListener("pointerdown", (event) => {
    if (!recording && !choices.hidden && !event.composedPath().includes(host)) closeChoices();
  }, true);
  document.addEventListener("keydown", (event) => {
    if (!recording && event.key === "Escape" && !choices.hidden) closeChoices();
  });

  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  window.addEventListener("scroll", schedule, { capture: true, passive: true });
  window.addEventListener("resize", schedule);
  document.addEventListener("loadedmetadata", schedule, true);
  document.addEventListener("play", schedule, true);
  schedule();
})();


