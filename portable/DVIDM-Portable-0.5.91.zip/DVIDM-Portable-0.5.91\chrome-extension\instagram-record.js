async function recordInstagramPlayer(video, stillSelected, progress) {
  if (typeof video.captureStream !== "function" || typeof MediaRecorder !== "function") {
    throw new Error("This browser cannot record the player");
  }
  if (!Number.isFinite(video.duration) || video.duration <= 0 || video.duration > 15 * 60 ||
      !video.seekable.length || video.seekable.start(0) > 0.1) {
    throw new Error("The entire video must be seekable");
  }

  const loop = video.loop;
  const rate = video.playbackRate;
  const wasPaused = video.paused;
  const previousTime = video.currentTime;
  let stream;
  let recorder;
  const cleanup = new AbortController();
  const options = { signal: cleanup.signal };
  const stopTracks = () => stream?.getTracks().forEach((track) => track.stop());
  try {
    video.pause();
    video.loop = false;
    video.playbackRate = 1;
    if (video.currentTime > 0.05 || video.ended || video.seeking) {
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("Could not seek to the start")), 5000);
        video.addEventListener("seeked", () => {
          clearTimeout(timer);
          resolve();
        }, { ...options, once: true });
        video.currentTime = 0;
      });
    }
    if (!stillSelected()) throw new Error("Video changed");
    stream = video.captureStream();
    const audio = stream.getAudioTracks()[0];
    if (!audio || !stream.getVideoTracks().length) throw new Error("The player did not expose audio and video");
    const mime = ["video/mp4;codecs=avc1.42001f,mp4a.40.2", "video/webm;codecs=vp8,opus"]
      .find((type) => MediaRecorder.isTypeSupported(type));
    if (!mime) throw new Error("No supported audio and video recording format");
    recorder = new MediaRecorder(stream, { mimeType: mime });
    return await new Promise((resolve, reject) => {
      const chunks = [];
      let bytes = 0;
      let finished = false;
      let heardAudio = !audio.muted;
      const fail = (message) => reject(new Error(message));
      const timer = setInterval(() => {
        if (!stillSelected()) fail("Video changed before recording finished");
        heardAudio ||= !audio.muted;
        progress(Math.min(99, Math.floor(video.currentTime / video.duration * 100)));
      }, 250);
      cleanup.signal.addEventListener("abort", () => clearInterval(timer), { once: true });
      const deadline = setTimeout(() => fail("Playback did not finish in time"), (video.duration + 120) * 1000);
      cleanup.signal.addEventListener("abort", () => clearTimeout(deadline), { once: true });

      recorder.ondataavailable = ({ data }) => {
        bytes += data.size;
        if (bytes > 192 * 1024 * 1024) fail("Recording exceeds 192 MB");
        else if (data.size) chunks.push(data);
      };
      recorder.onerror = () => fail("Chrome could not record this video");
      recorder.onstop = () => {
        if (!finished && !video.ended) return fail("Video ended before the full recording was captured");
        if (!heardAudio || !bytes) return fail("No usable audio was captured");
        resolve(new Blob(chunks, { type: mime }));
      };
      video.addEventListener("ended", () => {
        finished = true;
        if (recorder.state !== "inactive") recorder.stop();
      }, options);
      video.addEventListener("seeking", () => fail("Playback position changed during recording"), options);
      video.addEventListener("emptied", () => fail("Video source changed during recording"), options);
      video.addEventListener("waiting", () => {
        if (recorder.state === "recording") recorder.pause();
      }, options);
      video.addEventListener("playing", () => {
        if (recorder.state === "paused") recorder.resume();
      }, options);
      video.addEventListener("pause", () => {
        if (recorder.state === "recording") recorder.pause();
      }, options);
      recorder.start(1000);
      video.play().catch(() => fail("Chrome did not start playback"));
    });
  } finally {
    cleanup.abort();
    if (recorder && recorder.state !== "inactive") recorder.stop();
    stopTracks();
    if (stillSelected()) {
      video.pause();
      video.loop = loop;
      video.playbackRate = rate;
      video.currentTime = previousTime;
      if (!wasPaused) video.play().catch(() => {});
    }
  }
}
