function isInstagram(value) {
  try {
    return /^https:\/\/(?:www\.)?instagram\.com$/.test(new URL(value).origin);
  } catch {
    return false;
  }
}

function instagramPost(value) {
  if (!isInstagram(value)) return null;
  const url = new URL(value);
  const match = url.pathname.match(/^\/(?:[\w.]+\/)?(?:p|reel|reels|tv)\/([A-Za-z0-9_-]{1,16})\/?$/);
  return match ? { page: url.origin + url.pathname, shortcode: match[1] } : null;
}

function instagramCdnUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol === "https:" && !url.port && !url.username && !url.password &&
        /(?:^|\.)(?:cdninstagram\.com|fbcdn\.net)$/.test(url.hostname)) return url;
  } catch {
    // An unset or blob source does not identify a CDN file.
  }
  return null;
}

function instagramEncodingTag(url) {
  const encoding = url.searchParams.get("efg");
  if (!encoding) return "";
  try {
    return String(JSON.parse(atob(encoding.replace(/-/g, "+").replace(/_/g, "/"))).vencode_tag ?? "");
  } catch {
    return "";
  }
}

function instagramVideoUrl(value) {
  const url = instagramCdnUrl(value);
  if (!url || !/\.mp4$/i.test(url.pathname) || url.searchParams.has("bytestart") ||
      url.searchParams.has("byteend") || /dash/i.test(instagramEncodingTag(url))) return "";
  return url.href;
}

function instagramMediaUrls(media) {
  const items = media.carousel_media ??
    media.edge_sidecar_to_children?.edges?.map((edge) => edge.node) ?? [media];
  // A carousel post ID alone does not identify the playing slide.
  if (items.length !== 1) return [];
  return [...new Set(items.flatMap((item) => {
    const versions = (item.video_versions ?? []).slice().sort((a, b) =>
      b.width * b.height - a.width * a.height
    );
    const url = versions.map((version) => instagramVideoUrl(version.url)).find(Boolean) ||
      instagramVideoUrl(item.video_url);
    return url ? [url] : [];
  }))];
}

function instagramPageUrls(doc, shortcode) {
  // Relay preload data can contain the original file while the player uses a blob.
  for (const script of doc.querySelectorAll('script[data-sjs], script[type="application/json"]')) {
    if (!script.textContent.includes('"' + shortcode + '"')) continue;
    try {
      const pending = [JSON.parse(script.textContent)];
      while (pending.length) {
        const value = pending.pop();
        if (!value || typeof value !== "object") continue;
        if (value.code === shortcode || value.shortcode === shortcode) {
          const urls = instagramMediaUrls(value);
          if (urls.length) return urls;
        }
        for (const child of Object.values(value)) {
          if (child && typeof child === "object") pending.push(child);
        }
      }
    } catch {
      // Some scripts marked as data are not JSON.
    }
  }

  return [];
}

async function findInstagramVideos(video, post) {
  if (video) {
    // currentSrc identifies the selected source. A blob cannot leave the browser.
    const source = instagramVideoUrl(video.currentSrc || video.src ||
      video.querySelector("source[src]")?.src);
    if (source) return [source];
  }
  if (!post) return [];

  const { page, shortcode } = post;
  const local = instagramPageUrls(document, shortcode);
  if (local.length) return local;

  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  let mediaId = 0n;
  for (const character of shortcode) {
    mediaId = mediaId * 64n + BigInt(alphabet.indexOf(character));
  }
  try {
    const response = await fetch(location.origin + "/api/v1/media/" + mediaId + "/info/", {
      headers: { "X-IG-App-ID": "936619743392459", "X-ASBD-ID": "359341", "X-IG-WWW-Claim": "0" },
      credentials: "same-origin",
      redirect: "error",
      signal: AbortSignal.timeout(4000)
    });
    if (response.ok) {
      const media = (await response.json()).items?.[0];
      if (media?.code === shortcode) {
        const urls = instagramMediaUrls(media);
        if (urls.length) return urls;
      }
    }
  } catch {
    // The web endpoint may be unavailable, including on a logged-out page.
  }

  // After in-page navigation, the initial document may belong to a different post.
  if (!page.startsWith(location.origin + "/")) return [];
  try {
    const response = await fetch(page, {
      credentials: "same-origin",
      redirect: "error",
      signal: AbortSignal.timeout(4000)
    });
    if (response.ok) {
      const doc = new DOMParser().parseFromString(await response.text(), "text/html");
      return instagramPageUrls(doc, shortcode);
    }
  } catch {
    // The permalink may require login or may no longer be available.
  }
  return [];
}
