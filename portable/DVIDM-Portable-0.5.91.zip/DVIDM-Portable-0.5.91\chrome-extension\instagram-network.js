chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== "dvidm-instagram-save" || sender.id !== chrome.runtime.id ||
      sender.frameId !== 0 || !sender.tab || !isInstagram(sender.url)) return false;
  const url = instagramVideoUrl(message.url);
  if (!url) {
    reply({ error: "Invalid Instagram video address" });
    return false;
  }
  const name = String(message.title || "").replace(/[<>:"/\\|?*\x00-\x1f]/g, " ").trim().slice(0, 100);
  const filename = ["Instagram", name === "Instagram" ? "" : name].filter(Boolean).join(" - ") + ".mp4";
  const entry = { url, requestUrl: url, kind: "mp4", requireAudio: true };
  (async () => {
    await ensureOffscreenDocument();
    const result = await chrome.runtime.sendMessage({ type: "dvidm-recover-instagram", entry });
    if (!result?.url?.startsWith("blob:" + chrome.runtime.getURL(""))) {
      return { retry: true, filename, error: result?.error || "Extension request failed" };
    }
    await chrome.downloads.download({ url: result.url, filename });
    return { ok: true };
  })().then(reply, () => reply({ retry: true, filename, error: "Extension request failed" }));
  return true;
});
