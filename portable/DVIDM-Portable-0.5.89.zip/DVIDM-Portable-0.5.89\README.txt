DV Internet Download Manager 0.5.89 — Portable
================================================

No installation is required.

1. Extract this folder to a writable location, for example D:\DVIDM.
2. Run DVIDM.exe.
3. If Windows shows "Windows protected your PC", choose More info, then Run anyway.

Portable notes
--------------
- settings.json, catalog.json and DVIDM-debug.log are created next to
  DVIDM.exe, so the whole folder can be moved or deleted as one unit.
- Downloads save to your Windows Downloads folder by default. Change it in
  Settings > Save to.
- Partial files use %TEMP%\DVIDM by default. Change it in Settings >
  Temporary files.
- On first run, DVIDM enables "Start DVIDM with Windows". For a setup that
  leaves no trace outside this folder, turn that off in Settings > Startup;
  the startup entry is then removed.
- Keep the folder in one piece. If you move it, run DVIDM.exe once from the
  new location so the startup entry (if enabled) points to the right path.

Interface language
------------------
Settings > Appearance > Interface language offers System, English, فارسی
and العربية. System follows the Windows UI language. فارسی and العربية
switch the whole interface to right-to-left; the interface font is chosen
in Settings > Appearance.

Browser extension shortcut
--------------------------
Load the chrome-extension folder as an unpacked extension, then choose the
shortcut key in Settings > Browser shortcut: Ctrl, Alt, Shift, Insert,
Ctrl+Alt, Ctrl+Shift, Alt+Shift, or Ctrl or Alt. Hold that key and click a
file link to add it to DVIDM. File types are configured in the same card
(letters and digits, up to 32 characters; .safetensors is supported).

Selecting text on a page also shows a small DVIDM menu next to the pointer
with send/copy/link/page actions. Use the checkbox at the bottom of that
menu, or the extension toolbar popup, to turn the menu off.

Extensionless and authenticated links (for example Civitai model downloads)
are resolved by Chrome first so DVIDM receives the final CDN URL and the
server's filename. If Chrome cannot start the download, a fallback sends the
original link after a few seconds. If DVIDM is not running, Chrome keeps the
download instead of losing it.

Proxy
-----
Settings > Proxy supports No proxy, System (Windows Internet Settings) and
Manual. Manual mode accepts HTTP or SOCKS5 with optional credentials; the
Windows proxy is re-read while DVIDM runs.

Downloads list
--------------
- Use the small play/pause icon next to a list name to start or pause that
  list. While a list is downloading, the Start list button shows a small
  pulsing indicator.
- Opening a download's folder selects its file in Windows Explorer when the
  file exists.
- Deleting a download asks first; enable "Also delete the downloaded files
  from disk" to remove the file too.
- New downloads are scrolled into view; turn this off in Settings > Behavior.
- The Last date column shows when a download last started (or when it was
  added if it has not started yet). Hover for the complete date and time.
- Right-click a download > Properties shows its active download time and
  average speed; paused periods are not counted.
- Files are saved under the download list and category folders.

Updates
-------
Open the DV logo menu > Check for update. DVIDM asks GitHub for the latest
published release and shows the result with a link to the installer or the
release page. Choosing Download installer adds the MSI to DVIDM itself. A
fading message appears at startup when a newer version is available.

Browser extension
-----------------
1. Keep DVIDM running.
2. Open chrome://extensions (or edge://extensions).
3. Turn on Developer mode.
4. Choose Load unpacked and select the chrome-extension folder next to
   DVIDM.exe.
5. Pin the extension. Select links and choose "Send selected links", or use
   the right-click menu.

Documentation
-------------
- USER-GUIDE.pdf       English user guide
- USER-GUIDE.fa.pdf    Persian user guide
- install extension guide.mp4   Extension install video
- LICENSE.txt          End-user license

The same guides and video are available in the app from the DV logo menu >
User guide.
