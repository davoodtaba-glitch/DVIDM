DV Internet Download Manager 0.5.35 — Portable
================================================

No installation is required.

1. Extract this folder to a writable location, for example D:\DVIDM.
2. Run DVIDM.exe.
3. If Windows shows "Windows protected your PC", choose More info, then Run anyway.

Portable notes
--------------
- settings.json, catalog.json and DVIDM-debug.log are created next to
  DVIDM.exe, so the whole folder can be moved or deleted as one unit.
- Downloads save to your Windows Downloads folder by default. Change it in
  Settings > Save to.
- Partial files use %TEMP%\DVIDM by default. Change it in Settings >
  Temporary files.
- On first run, DVIDM enables "Start DVIDM with Windows". For a setup that
  leaves no trace outside this folder, turn that off in Settings > Startup;
  the startup entry is then removed.
- Keep the folder in one piece. If you move it, run DVIDM.exe once from the
  new location so the startup entry (if enabled) points to the right path.

Browser extension shortcut
--------------------------
With this folder loaded as an unpacked extension, Ctrl+click or Alt+click a
file link (.zip, .rar, .exe, .msi, .iso, .pdf, .mp4 and similar) to add it to
DVIDM and start it immediately. Normal page links still open in a new tab;
Ctrl+Shift+click is left to Chrome. If "Don't start immediately" is on, the
download is added paused. Reload the extension after updating its files.

Schedules
---------
Hover the clock next to a download list, or open its options, to see when
the scheduled session starts and how long it runs, for example:
  Downloads will start in 3 hours 30 minutes.
  Downloads will run for 4 hours 30 minutes.

The list options window updates these lines as you change the start and end
times. Downloads held by a schedule show a yellow "Scheduled" badge.

Downloads list
--------------
- New downloads are scrolled into view; turn this off in Settings > Behavior.
- The Last date column shows when a download last started (or when it was
  added if it has not started yet). Hover for the complete date and time.
- Right-click a download > Properties shows its active download time and
  average speed; paused periods are not counted.

Updates
-------
Open the DV logo menu > Check for update. DVIDM asks GitHub for the latest
published release and shows the result with a link to the installer or the
release page. Choosing Download installer adds the MSI to DVIDM itself. The
check also runs silently in the background every two days and shows a
notification when a new version is available.

Browser extension
-----------------
1. Keep DVIDM running.
2. Open chrome://extensions (or edge://extensions).
3. Turn on Developer mode.
4. Choose Load unpacked and select the chrome-extension folder next to
   DVIDM.exe.
5. Pin the extension. Select links and choose "Send selected links", or use
   the right-click menu.

Documentation
-------------
- USER-GUIDE.pdf       English user guide
- USER-GUIDE.fa.pdf    Persian user guide
- install extension guide.mp4   Extension install video
- LICENSE.txt          End-user license

The same guides and video are available in the app from the DV logo menu >
User guide.
