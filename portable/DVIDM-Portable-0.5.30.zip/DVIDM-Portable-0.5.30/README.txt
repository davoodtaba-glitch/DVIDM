DV Internet Download Manager 0.5.30 — Portable
================================================

No installation is required.

1. Extract this folder to a writable location, for example D:\DVIDM.
2. Run DVIDM.exe.
3. If Windows shows "Windows protected your PC", choose More info, then Run anyway.

Portable notes
--------------
- settings.json, catalog.json and DVIDM-debug.log are created next to
  DVIDM.exe, so the whole folder can be moved or deleted as one unit.
- Downloads save to your Windows Downloads folder by default. Change it in
  Settings > Save to.
- Partial files use %TEMP%\DVIDM by default. Change it in Settings >
  Temporary files.
- On first run, DVIDM enables "Start DVIDM with Windows". For a setup that
  leaves no trace outside this folder, turn that off in Settings > Startup;
  the startup entry is then removed.
- Keep the folder in one piece. If you move it, run DVIDM.exe once from the
  new location so the startup entry (if enabled) points to the right path.

Updates
-------
Open the DV logo menu > Check for update. DVIDM asks GitHub for the latest
published release and shows whether a newer version exists, with a link to
the installer. The portable zip is on the same release page.

Browser extension
-----------------
1. Keep DVIDM running.
2. Open chrome://extensions (or edge://extensions).
3. Turn on Developer mode.
4. Choose Load unpacked and select the chrome-extension folder next to
   DVIDM.exe.
5. Pin the extension. Select links and choose "Send selected links", or use
   the right-click menu.

Documentation
-------------
- USER-GUIDE.pdf       English user guide
- USER-GUIDE.fa.pdf    Persian user guide
- install extension guide.mp4   Extension install video
- LICENSE.txt          End-user license

The same guides and video are available in the app from the DV logo menu >
User guide.
