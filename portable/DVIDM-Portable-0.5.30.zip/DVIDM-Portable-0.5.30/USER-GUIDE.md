# DV Internet Download Manager — User Guide

Version 0.5.27 · Windows 10/11

DV Internet Download Manager (DVIDM) is a desktop download manager with
segmented downloads, download lists, scheduling, clipboard/Chrome import, a
custom completion notification, and a dark/light interface.

---

## 1. Installation

1. Extract `DVIDM-Setup.zip`.
2. Run `DVIDM-Setup.msi` and follow the wizard.
   - Installs per user in `%LOCALAPPDATA%\Programs\DVIDM` (no administrator
     rights needed).
   - Adds Desktop and Start Menu shortcuts.
   - Can be uninstalled from **Settings → Apps → Installed apps**.
   - The installer is unsigned, so Windows SmartScreen may warn.
3. Start DVIDM from the shortcut.

### Installing the browser extension

The extension is **not installed automatically** (Chrome no longer allows
silent unpacked extension installs). Install it once manually:

1. Open `chrome://extensions` (or `edge://extensions` in Edge).
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked**.
4. Select the `chrome-extension` folder from:
   - the extracted `DVIDM-Setup` folder, or
   - `%LOCALAPPDATA%\Programs\DVIDM\chrome-extension`.
5. Pin DVIDM from the extensions (puzzle) menu.

After updating DVIDM, click **Reload** on the extension card if needed.

---

## 2. Adding downloads

### From the URL bar
Paste an `http(s)` link into the URL field and press **Download** (or Enter).

### From the clipboard
Click **Clipboard**. If the clipboard contains several links, a review window
opens; choose the links, a destination list, and press **Add**.

### From Chrome/Edge
The extension sends links to DVIDM over a local connection
(`127.0.0.1:52137`); DVIDM must be running. A review window titled **From
Chrome** opens, where you can uncheck links, choose a list, and press **Add**.

Extension controls:
- **Send selected links on page** and **Copy selected links** in the popup.
- Right-click menus: **Download link with DVIDM**, **Send selected links to
  DVIDM**, **Copy selected links**, **Send this page to DVIDM**.

### Don't start immediately
The **Don't start immediately** toggle (toolbar and review windows) adds new
downloads paused. Use **Start / Start list** to begin them later. List limits
never start these automatically.

---

## 3. The main window

### Toolbar
- **Start list / Pause list / Delete all from list** act on the current view
  when nothing is selected; with rows selected they become **Start / Pause /
  Delete** and act on the selection.
- **↑ / ↓** move selected rows up/down the queue (sorting must be off).
- **List** adds selected rows to a download list.
- **Search downloads…** filters by file name.

### Download table
Columns: number, Status, Lists, File name, Size, Progress, Speed, ETA, Parts,
Last date, Actions.

- Click any sortable header to sort; click again to reverse; a third click
  clears the sort. The sort state is saved for the next launch.
- **Last date** shows the completion date; older completed rows fall back to
  their added date.
- Select rows with the checkboxes. You can press on a checkbox and **drag down**
  to select/deselect several rows.

### Row actions
- **Folder/file button** — opens the finished file, or the folder while the
  download is incomplete. Right-click opens the folder.
- **Play/Pause button** — starts or pauses the download.
- **Yellow circular arrow** (completed rows) — download the file again; a
  warning lets you choose **Keep the old file** (a second copy is saved) or
  replace the old file.
- **List button** — add the row to a list.
- **Delete button** — remove the row (confirmation dialog).

### File Properties
Right-click a row to open **File Properties**: type, status, size, save path,
address, downloaded amount, progress and lists.

- **Address** can be edited only while the download is paused. Progress is
  kept, so use a mirror or refreshed link of the same file.
- **Open** opens the file or folder; **OK** closes.

---

## 4. Download lists

The sidebar contains Library categories and Download Lists. The sidebar can be
widened/narrowed by dragging the divider (220–420 px); the width is saved.

Each list shows:
- a coloured list icon,
- a play indicator when one of its unfinished downloads is active,
- a pause indicator when nothing is running (amber when everything unfinished
  is paused, dim when the list is empty/finished),
- a dim clock, which turns amber when a schedule is active,
- its unfinished-download count,
- options (⋯) and delete (trash) buttons.

### List options
Click ⋯ or right-click a list:
- Rename, colour, maximum parallel downloads.
- Optional time window (start/end) and “shut down when the window ends”.
- **Save list…** — writes the list’s unfinished URLs to a `.txt` file.
- **Load list…** — choose one or more `.txt` files and add their links through
  the same review window used by clipboard import.

Delete a list with the trash button; a confirmation appears. **Shift-click**
skips the confirmation. Downloads are not deleted.

---

## 5. Settings

Open **Settings** at the bottom of the sidebar (the same button reads
**Close settings** while open).

- **Appearance** — light/dark theme.
- **Startup** — **Start DVIDM with Windows** (per-user startup entry).
- **Notifications** — enable/disable the completion notification.
- **Save to** — destination folder for new downloads (default: Windows
  Downloads).
- **Temporary files** — folder for partial files (default:
  `%TEMP%\DVIDM`). Changing it moves partial files for paused downloads;
  pause active downloads first.
- **Connections** — parallel parts per file (1–32).
- **Speed limit** — Unlimited, presets, or a custom KB/s value.
- **Retry** — re-download failed parts and the wait between attempts.
- **Interface font** — choose an installed font.

If a saved download or temp folder is unavailable on this PC (for example a
`G:\...` path on a machine without a G: drive), DVIDM automatically falls back
to this PC’s Windows Downloads folder / `%TEMP%\DVIDM` and saves that choice.

---

## 6. Notifications

When a download finishes, a dark card appears in the bottom-right corner of the
monitor (not a standard Windows notification): green check, “Download complete”,
and the file name.

- It closes after 5 seconds; click it to close immediately.
- Turn it off under **Settings → Notifications**.

---

## 7. Tray and background

- Closing the window hides DVIDM to the notification area; downloads keep
  running.
- Left-click the tray icon to reopen the window.
- Right-click the tray icon for **Open** and **Exit**.
- Only one DVIDM instance can run at a time.

---

## 8. Status bar

Shows the number of files, active downloads, connections, current limit, total
speed, and free space on the destination drive.

Icons on the right:
- **Logs** — open the debug log window.
- **App folder** — open the folder containing `DVIDM.exe`.

---

## 9. Files and data

Settings and history live next to the executable:

| File | Purpose |
| --- | --- |
| `settings.json` | Preferences, lists, sort state |
| `catalog.json` | Download rows and progress state |
| `DVIDM-debug.log` | Temporary diagnostic log |

Default folders:
- Finished downloads: Windows Downloads (fallback: `<app>\downloads`).
- Partial files: `%TEMP%\DVIDM` (fallback: `<app>\temp`).

For an installed copy these files are in
`%LOCALAPPDATA%\Programs\DVIDM`.

---

## 10. Debug log

Click the **Logs** icon in the status bar. The log opens in its own window with
selectable text, plus **Refresh**, **Copy all**, **Open file**, and **Close**.
It records commands, download state changes/errors, window visibility, and
panics — useful when reporting a problem. Send the log file or **Copy all**
output.

---

## 11. Troubleshooting

| Problem | What to try |
| --- | --- |
| Extension shows **Offline** | Start DVIDM; make sure port 52137 is free. |
| Extension sends nothing | Reload the extension in `chrome://extensions`; keep DVIDM running. |
| Download shows **Failed** | Open File Properties to see the stored error; check the URL, disk space and destination permissions. |
| Open/folder does nothing | Verify the folder still exists; move the download entry or use File Properties. |
| Downloads start when they shouldn’t | Turn on **Don't start immediately** before adding; queued rows never auto-start from a list cap. |
| Completion card missing | Enable **Settings → Notifications**; check Windows notifications are enabled. |
| Wrong paths after moving to another PC | DVIDM resets unavailable download/temp folders to Windows defaults automatically. |
| App won’t open | It may already be running in the tray (single instance). |

### Uninstalling
Use **Settings → Apps → Installed apps → DV Internet Download Manager**.
Uninstalling removes the program files. Downloads, `settings.json` and
`catalog.json` may remain in `%LOCALAPPDATA%\Programs\DVIDM`; delete that folder
manually if you also want to remove user data.
